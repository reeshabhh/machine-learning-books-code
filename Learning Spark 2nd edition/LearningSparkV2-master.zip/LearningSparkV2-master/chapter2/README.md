This directory contains all the Scala and Python examples for Chapter 2, along with the code to generate the M&Ms data set.

To build and run these examples cd in the respective scala or py/src directory and follow the instructions in the relevant README.md files.
