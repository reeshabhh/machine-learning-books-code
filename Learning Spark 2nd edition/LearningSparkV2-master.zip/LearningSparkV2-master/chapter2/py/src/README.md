### How to run the M&M Example
To run the Python code for this chapter:

 * `spark-submit mnmcount.py data/mnm_dataset.csv`
