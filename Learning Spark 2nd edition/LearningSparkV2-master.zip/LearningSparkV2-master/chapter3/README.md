This directory contains the Scala and Python examples for Chapter 3.

To build and run these examples cd in the respective scala or py/src directory and follow the instructions in the relevant README.md files.
