### How to run the code
To run the Python code for this chapter use:

 * `spark-submit Example-3_6.py`
 * `spark-submit rows.py`

Have Fun
Cheers!

