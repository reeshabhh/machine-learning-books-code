This directory contains the Scala examples for Chapter 7.

To build and run these examples cd in the scala directory and follow the instructions in the README.md file.
