# Weblog Access Dataset

This is fake data created to illustrate a small example. The code used to generate this data
is used from an open source github tool [Fake-Apache-Log-Generator](https://github.com/kiritbasu/Fake-Apache-Log-Generator.git)

### LICENSE
This tool complies with a license Apache 2.0, and its terms for using this tool are at [LICENSE](https://github.com/kiritbasu/Fake-Apache-Log-Generator/blob/master/LICENSE)
