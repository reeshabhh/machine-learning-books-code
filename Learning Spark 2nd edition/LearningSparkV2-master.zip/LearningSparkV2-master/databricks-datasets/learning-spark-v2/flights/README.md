# On-Time Performance Datasets

The source `airports` dataset can be found at [OpenFlights Airport, airline and route data](http://openflights.org/data.html). 

The `flights`, also known as the `departuredelays`, dataset can be found at [Airline On-Time Performance and Causes of Flight Delays: On_Time Data](https://catalog.data.gov/dataset/airline-on-time-performance-and-causes-of-flight-delays)
