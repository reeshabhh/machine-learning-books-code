
==========================================
Lending Club Statistics
==========================================

This data set was obtained from https://www.lendingclub.com/info/download-data.action.  The source of the data is: LendingClub, LendingClub Corporation Dept. 34268
,P.O. Box 39000, San Francisco, CA 94139

=========================================
Data Set Information
=========================================

These files contain complete loan data for all loans issued through the time period stated, including the current loan status (Current, Late, Fully Paid, etc.) and latest payment information. The file containing loan data through the "present" contains complete loan data for all loans issued through the previous completed calendar quarter.
	
=========================================
License and/or Citation
=========================================

Lending Club's website does not explicitly state which license it is sharing the data under. However, it is stated explicitly on the URL where one downloads the data that "Want to slice and dice the data? Help yourself to the following exports of our loan databases."